/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;

import Logica.Circulo;
import Logica.Cuadrado;
import Logica.FiguraGeometrica;
import Logica.Rectangulo;
import java.util.Scanner;

public class Mostrar {
    
    
    public static void main(String[] args) {
    
        VentanaPrincipal ven=new VentanaPrincipal();
        ven.setVisible(true);
    }  
      
    
    
}